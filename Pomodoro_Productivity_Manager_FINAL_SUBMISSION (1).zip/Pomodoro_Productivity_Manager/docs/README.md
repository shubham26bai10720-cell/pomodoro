# Design and Submission Artifacts

This folder contains the project design and evidence artifacts:
- architecture.png
- workflow.png
- use_case.png
- class_diagram.png
- sequence_diagram.png
- screenshots/01_main_screen.png
- screenshots/02_task_screen.png
- Project_Report.pdf is stored at the project root.

The diagrams are provided in both SVG and PNG formats where available.
