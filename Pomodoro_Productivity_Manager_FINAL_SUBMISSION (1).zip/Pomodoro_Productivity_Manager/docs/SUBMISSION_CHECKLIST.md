# Submission Checklist

## Application
- [x] Modular Python source code
- [x] OOP/classes
- [x] Functions and control flow
- [x] Data structures
- [x] Input validation and error handling
- [x] Local JSON storage
- [x] Unit tests

## Documentation
- [x] README.md
- [x] statement.md
- [x] Project_Report.pdf
- [x] Functional requirements
- [x] Non-functional requirements
- [x] Architecture diagram
- [x] Workflow diagram
- [x] Use Case diagram
- [x] Class diagram
- [x] Sequence diagram
- [x] Storage design/schema
- [x] Screenshots/results

## External submission step
- [ ] Create GitHub repository
- [ ] Push project source and documentation
- [ ] Make version-control commits
- [ ] Upload required PDF/repository information to VITyarthi portal
