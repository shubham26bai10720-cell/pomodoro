# Pomodoro Productivity Manager

A desktop productivity application built with Python and Tkinter. It implements the Pomodoro technique with configurable focus/break sessions, automatic session transitions, task tracking, statistics, notifications, and persistent local data.

## Features

- Start, pause, resume, and reset timer
- Focus, short-break, and long-break modes
- Automatic transition between sessions
- Configurable focus, short-break, long-break durations
- Configurable sessions before a long break
- Daily task list with completion status
- Completed-session statistics
- Session history saved locally in JSON
- Progress bar and session counter
- Input validation and error handling
- Clean modular OOP architecture

## Technologies

- Python 3
- Tkinter
- JSON
- datetime
- unittest

## Project Structure

```text
Pomodoro_Productivity_Manager/
├── main.py
├── requirements.txt
├── README.md
├── statement.md
├── app/
│   ├── __init__.py
│   ├── gui.py
│   ├── timer.py
│   ├── session_manager.py
│   ├── settings.py
│   ├── task_manager.py
│   ├── statistics.py
│   ├── notification.py
│   └── storage.py
├── tests/
│   ├── __init__.py
│   └── test_core.py
└── data/
    └── .gitkeep
```

## How to Run

1. Install Python 3.10 or newer.
2. Clone/download the project.
3. Open a terminal in the project folder.
4. Run:

```bash
python main.py
```

No external dependency installation is required.

## Testing

Run:

```bash
python -m unittest discover -s tests -v
```

The tests validate settings, timer state transitions, task management, and statistics.

## Data Storage

Application data is stored locally in `data/pomodoro_data.json`. The application creates the file automatically after data is saved.
