import unittest

from app.settings import TimerSettings
from app.timer import CountdownTimer
from app.session_manager import SessionManager, SessionType
from app.task_manager import TaskManager
from app.statistics import Statistics


class TestSettings(unittest.TestCase):
    def test_valid_settings(self):
        settings = TimerSettings(25, 5, 15, 4)
        settings.validate()

    def test_invalid_settings(self):
        with self.assertRaises(ValueError):
            TimerSettings(0, 5, 15, 4).validate()


class TestTimer(unittest.TestCase):
    def test_tick_reaches_zero(self):
        timer = CountdownTimer(2)
        timer.start()
        self.assertFalse(timer.tick())
        self.assertTrue(timer.tick())
        self.assertTrue(timer.finished)
        self.assertFalse(timer.running)

    def test_pause_stops_countdown(self):
        timer = CountdownTimer(10)
        timer.start()
        timer.pause()
        self.assertFalse(timer.tick())
        self.assertEqual(timer.remaining_seconds, 10)


class TestSessionManager(unittest.TestCase):
    def test_four_focus_sessions_trigger_long_break(self):
        settings = TimerSettings(25, 5, 15, 4)
        manager = SessionManager(settings)

        for _ in range(4):
            manager.session_type = SessionType.FOCUS
            manager.complete_current_session()

        self.assertEqual(manager.session_type, SessionType.LONG_BREAK)


class TestTaskManager(unittest.TestCase):
    def test_add_and_complete_task(self):
        manager = TaskManager()
        manager.add_task("Study Python")
        manager.complete_task(0)
        self.assertTrue(manager.tasks[0].completed)


class TestStatistics(unittest.TestCase):
    def test_record_session(self):
        stats = Statistics()
        stats.record_focus_session(25)
        self.assertEqual(stats.completed_sessions, 1)
        self.assertEqual(stats.total_focus_minutes, 25)


if __name__ == "__main__":
    unittest.main()
