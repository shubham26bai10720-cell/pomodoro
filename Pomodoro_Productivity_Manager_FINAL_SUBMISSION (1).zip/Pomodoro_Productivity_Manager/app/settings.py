from dataclasses import dataclass


@dataclass
class TimerSettings:
    focus_minutes: int = 25
    short_break_minutes: int = 5
    long_break_minutes: int = 15
    sessions_before_long_break: int = 4

    def validate(self) -> None:
        values = {
            "Focus duration": self.focus_minutes,
            "Short break duration": self.short_break_minutes,
            "Long break duration": self.long_break_minutes,
            "Sessions before long break": self.sessions_before_long_break,
        }
        for name, value in values.items():
            if not isinstance(value, int) or value <= 0:
                raise ValueError(f"{name} must be a positive whole number.")
