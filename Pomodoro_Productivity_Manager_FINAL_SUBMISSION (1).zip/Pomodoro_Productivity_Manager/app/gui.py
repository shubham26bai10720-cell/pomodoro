import tkinter as tk
from tkinter import ttk, messagebox, simpledialog

from .notification import NotificationService
from .session_manager import SessionManager, SessionType
from .settings import TimerSettings
from .statistics import Statistics
from .storage import Storage
from .task_manager import TaskManager
from .timer import CountdownTimer


class PomodoroGUI:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Pomodoro Productivity Manager")
        self.root.geometry("760x650")
        self.root.minsize(700, 600)

        self.settings = TimerSettings()
        self.session_manager = SessionManager(self.settings)
        self.timer = CountdownTimer(self.session_manager.duration_seconds())
        self.tasks = TaskManager()
        self.statistics = Statistics()
        self.storage = Storage()

        self._load_data()
        self._build_ui()
        self._refresh_display()

    def _load_data(self):
        data = self.storage.load()
        try:
            self.tasks.from_dict(data.get("tasks", []))
            self.statistics.from_dict(data.get("statistics", {}))
        except (KeyError, TypeError, ValueError):
            self.tasks = TaskManager()
            self.statistics = Statistics()

    def _save_data(self):
        self.storage.save(self.tasks.to_dict(), self.statistics.to_dict())

    def _build_ui(self):
        style = ttk.Style()
        style.configure("Title.TLabel", font=("Segoe UI", 24, "bold"))
        style.configure("Timer.TLabel", font=("Segoe UI", 56, "bold"))
        style.configure("Mode.TLabel", font=("Segoe UI", 16, "bold"))

        container = ttk.Frame(self.root, padding=20)
        container.pack(fill="both", expand=True)

        ttk.Label(container, text="Pomodoro Productivity Manager",
                  style="Title.TLabel").pack(pady=(0, 8))

        self.mode_label = ttk.Label(container, style="Mode.TLabel")
        self.mode_label.pack()

        self.timer_label = ttk.Label(container, style="Timer.TLabel")
        self.timer_label.pack(pady=15)

        self.progress = ttk.Progressbar(container, mode="determinate", length=520)
        self.progress.pack(pady=5)

        self.session_label = ttk.Label(container)
        self.session_label.pack(pady=5)

        controls = ttk.Frame(container)
        controls.pack(pady=12)
        ttk.Button(controls, text="Start / Resume",
                   command=self.start_timer).grid(row=0, column=0, padx=5)
        ttk.Button(controls, text="Pause",
                   command=self.pause_timer).grid(row=0, column=1, padx=5)
        ttk.Button(controls, text="Reset",
                   command=self.reset_timer).grid(row=0, column=2, padx=5)
        ttk.Button(controls, text="Settings",
                   command=self.change_settings).grid(row=0, column=3, padx=5)

        notebook = ttk.Notebook(container)
        notebook.pack(fill="both", expand=True, pady=15)

        task_frame = ttk.Frame(notebook, padding=15)
        stats_frame = ttk.Frame(notebook, padding=15)
        notebook.add(task_frame, text="Tasks")
        notebook.add(stats_frame, text="Statistics")

        self.task_entry = ttk.Entry(task_frame)
        self.task_entry.pack(fill="x", pady=5)
        ttk.Button(task_frame, text="Add Task",
                   command=self.add_task).pack(pady=4)

        self.task_list = tk.Listbox(task_frame, height=8)
        self.task_list.pack(fill="both", expand=True, pady=5)

        task_buttons = ttk.Frame(task_frame)
        task_buttons.pack()
        ttk.Button(task_buttons, text="Complete",
                   command=self.complete_task).grid(row=0, column=0, padx=5)
        ttk.Button(task_buttons, text="Delete",
                   command=self.delete_task).grid(row=0, column=1, padx=5)

        self.stats_label = ttk.Label(stats_frame, justify="left",
                                     font=("Segoe UI", 12))
        self.stats_label.pack(anchor="nw")

        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _refresh_display(self):
        minutes, seconds = divmod(self.timer.remaining_seconds, 60)
        self.timer_label.config(text=f"{minutes:02d}:{seconds:02d}")
        self.mode_label.config(text=self.session_manager.session_type.value)

        total = max(self.timer.initial_seconds, 1)
        elapsed = total - self.timer.remaining_seconds
        self.progress["maximum"] = total
        self.progress["value"] = elapsed

        self.session_label.config(
            text=f"Focus sessions completed: {self.session_manager.completed_focus_sessions}"
        )

        self.task_list.delete(0, tk.END)
        for task in self.tasks.tasks:
            mark = "✓" if task.completed else "○"
            self.task_list.insert(tk.END, f"{mark} {task.title}")

        self.stats_label.config(
            text=(
                f"Completed focus sessions: {self.statistics.completed_sessions}\n"
                f"Total focus time: {self.statistics.total_focus_minutes} minutes\n"
                f"Today's sessions: {self.statistics.today_sessions()}\n\n"
                "Use the Tasks tab to organize your work."
            )
        )

    def start_timer(self):
        self.timer.start()
        self._tick()

    def _tick(self):
        if not self.timer.running:
            self._refresh_display()
            return

        finished = self.timer.tick()
        self._refresh_display()

        if finished:
            self._session_finished()
        else:
            self.root.after(1000, self._tick)

    def pause_timer(self):
        self.timer.pause()
        self._refresh_display()

    def reset_timer(self):
        self.timer.reset()
        self._refresh_display()

    def _session_finished(self):
        completed_type = self.session_manager.session_type
        if completed_type == SessionType.FOCUS:
            self.statistics.record_focus_session(self.settings.focus_minutes)

        self.session_manager.complete_current_session()
        self.timer.set_duration(self.session_manager.duration_seconds())
        self._save_data()

        NotificationService.notify(
            self.root,
            "Session Complete",
            f"{completed_type.value} session finished. Next: "
            f"{self.session_manager.session_type.value}."
        )
        messagebox.showinfo(
            "Session Complete",
            f"{completed_type.value} session finished.\n"
            f"Next session: {self.session_manager.session_type.value}."
        )
        self._refresh_display()

    def add_task(self):
        try:
            self.tasks.add_task(self.task_entry.get())
            self.task_entry.delete(0, tk.END)
            self._save_data()
            self._refresh_display()
        except ValueError as exc:
            messagebox.showwarning("Invalid Task", str(exc))

    def complete_task(self):
        selection = self.task_list.curselection()
        if not selection:
            messagebox.showwarning("Task", "Select a task first.")
            return
        self.tasks.complete_task(selection[0])
        self._save_data()
        self._refresh_display()

    def delete_task(self):
        selection = self.task_list.curselection()
        if not selection:
            messagebox.showwarning("Task", "Select a task first.")
            return
        self.tasks.remove_task(selection[0])
        self._save_data()
        self._refresh_display()

    def change_settings(self):
        values = []
        prompts = [
            ("Focus duration (minutes)", self.settings.focus_minutes),
            ("Short break (minutes)", self.settings.short_break_minutes),
            ("Long break (minutes)", self.settings.long_break_minutes),
            ("Sessions before long break", self.settings.sessions_before_long_break),
        ]

        for prompt, current in prompts:
            value = simpledialog.askinteger(
                "Settings", prompt, initialvalue=current, minvalue=1, parent=self.root
            )
            if value is None:
                return
            values.append(value)

        new_settings = TimerSettings(*values)
        try:
            new_settings.validate()
        except ValueError as exc:
            messagebox.showerror("Invalid Settings", str(exc))
            return

        self.settings = new_settings
        self.session_manager.settings = new_settings
        self.timer.set_duration(self.session_manager.duration_seconds())
        self._refresh_display()

    def close(self):
        self._save_data()
        self.root.destroy()

    def run(self):
        self.root.mainloop()
