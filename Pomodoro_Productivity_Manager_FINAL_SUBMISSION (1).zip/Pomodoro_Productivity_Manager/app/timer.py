class CountdownTimer:
    """Reusable countdown timer state model."""

    def __init__(self, seconds: int):
        if seconds <= 0:
            raise ValueError("Timer duration must be positive.")
        self.initial_seconds = seconds
        self.remaining_seconds = seconds
        self.running = False

    def start(self):
        self.running = True

    def pause(self):
        self.running = False

    def reset(self):
        self.remaining_seconds = self.initial_seconds
        self.running = False

    def tick(self) -> bool:
        """Decrease by one second. Returns True when the timer reaches zero."""
        if not self.running:
            return False

        if self.remaining_seconds > 0:
            self.remaining_seconds -= 1

        if self.remaining_seconds == 0:
            self.running = False
            return True
        return False

    @property
    def finished(self) -> bool:
        return self.remaining_seconds == 0

    def set_duration(self, seconds: int):
        if seconds <= 0:
            raise ValueError("Timer duration must be positive.")
        self.initial_seconds = seconds
        self.remaining_seconds = seconds
        self.running = False
