from enum import Enum
from .settings import TimerSettings


class SessionType(Enum):
    FOCUS = "Focus"
    SHORT_BREAK = "Short Break"
    LONG_BREAK = "Long Break"


class SessionManager:
    """Controls the Pomodoro work/break cycle."""

    def __init__(self, settings: TimerSettings):
        settings.validate()
        self.settings = settings
        self.session_type = SessionType.FOCUS
        self.completed_focus_sessions = 0

    def duration_seconds(self) -> int:
        minutes = {
            SessionType.FOCUS: self.settings.focus_minutes,
            SessionType.SHORT_BREAK: self.settings.short_break_minutes,
            SessionType.LONG_BREAK: self.settings.long_break_minutes,
        }[self.session_type]
        return minutes * 60

    def complete_current_session(self):
        if self.session_type == SessionType.FOCUS:
            self.completed_focus_sessions += 1
            if self.completed_focus_sessions % self.settings.sessions_before_long_break == 0:
                self.session_type = SessionType.LONG_BREAK
            else:
                self.session_type = SessionType.SHORT_BREAK
        else:
            self.session_type = SessionType.FOCUS

    def reset_cycle(self):
        self.session_type = SessionType.FOCUS
        self.completed_focus_sessions = 0
