import tkinter as tk


class NotificationService:
    @staticmethod
    def notify(root: tk.Tk, title: str, message: str):
        try:
            root.bell()
        except tk.TclError:
            pass

        try:
            root.after(0, lambda: root.title(f"{title} - Pomodoro Productivity Manager"))
        except tk.TclError:
            pass
