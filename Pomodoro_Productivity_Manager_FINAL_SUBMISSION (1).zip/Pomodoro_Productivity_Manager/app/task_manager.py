from dataclasses import dataclass, asdict


@dataclass
class Task:
    title: str
    completed: bool = False


class TaskManager:
    def __init__(self):
        self.tasks = []

    def add_task(self, title: str):
        title = title.strip()
        if not title:
            raise ValueError("Task title cannot be empty.")
        self.tasks.append(Task(title))

    def complete_task(self, index: int):
        self.tasks[index].completed = True

    def remove_task(self, index: int):
        del self.tasks[index]

    def to_dict(self):
        return [asdict(task) for task in self.tasks]

    def from_dict(self, items):
        self.tasks = [Task(item["title"], bool(item.get("completed", False)))
                      for item in items]
