import json
from pathlib import Path


class Storage:
    def __init__(self, filename="data/pomodoro_data.json"):
        self.path = Path(filename)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def save(self, tasks, statistics):
        payload = {
            "tasks": tasks,
            "statistics": statistics,
        }
        self.path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def load(self):
        if not self.path.exists():
            return {"tasks": [], "statistics": {}}

        try:
            return json.loads(self.path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"tasks": [], "statistics": {}}
