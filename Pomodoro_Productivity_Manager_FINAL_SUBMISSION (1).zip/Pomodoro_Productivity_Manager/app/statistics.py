from datetime import date


class Statistics:
    def __init__(self):
        self.completed_sessions = 0
        self.total_focus_minutes = 0
        self.history = []

    def record_focus_session(self, minutes: int):
        self.completed_sessions += 1
        self.total_focus_minutes += minutes
        self.history.append({
            "date": date.today().isoformat(),
            "minutes": minutes,
        })

    def today_sessions(self) -> int:
        today = date.today().isoformat()
        return sum(1 for item in self.history if item.get("date") == today)

    def to_dict(self):
        return {
            "completed_sessions": self.completed_sessions,
            "total_focus_minutes": self.total_focus_minutes,
            "history": self.history,
        }

    def from_dict(self, data):
        self.completed_sessions = int(data.get("completed_sessions", 0))
        self.total_focus_minutes = int(data.get("total_focus_minutes", 0))
        self.history = list(data.get("history", []))
