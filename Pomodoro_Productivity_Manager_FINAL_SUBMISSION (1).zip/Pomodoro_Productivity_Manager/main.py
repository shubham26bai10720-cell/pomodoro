from app.gui import PomodoroGUI

if __name__ == "__main__":
    app = PomodoroGUI()
    app.run()
